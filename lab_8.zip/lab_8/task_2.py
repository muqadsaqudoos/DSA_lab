class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
    def set_value(self, value):
            self.value = value
    def set_left(self, left):
        self.left = left
    def set_right(self, right):
        self.right = right
    def get_value(self):
        return self.value
    def get_left(self):
        return self.left
    def get_right(self):
        return self.right
    
class BinarySearchTree:
    def __init__(self):
        self.root = None

    def insert_element(self, value):
        if self.root == None:
            self.root = Node(value)
            return
        current = self.root
        while current:
            if value>current.value:
                if current.right is None:
                    current.right = Node(value)
                    return
                else:
                    current = current.right
            else:
                if current.left is None:
                    current.left = Node(value)
                    return
                else:
                    current = current.left
                
    
    def deleteNode(self, value):
        def delnode(root,key):
            if root is None:
                return root

            if key < root.value:
                root.left = delnode(root.left, key)
            elif key > root.value:
                root.right = delnode(root.right, key)
           
            else:
                if root.left is None:
                    return root.right
                elif root.right is None:
                    return root.left

                root.value = self.minValue(root.right)
                root.right = delnode(root.right, root.value)

            return root
        self.root = delnode(self.root,value)

    def minValue(self, root):
        minv = root.value
        while root.left:
            minv = root.left.value
            root = root.left
        return minv
        
    def display_pre_order(self):
        self.helper_pre_order(self.root)
    def helper_pre_order(self,node):
        if node:
            print(node.value , end= " ")
            self.helper_pre_order(node.left)
            self.helper_pre_order(node.right)
            
    def display_in_order(self):
        self.helper_in_order(self.root)
    def helper_in_order(self,node):
        if node:
            self.helper_in_order(node.left)   
            print(node.value , end= " ")  
            self.helper_in_order(node.right)     
    def display_post_order(self):
        self.helper_post_order(self.root)

    def helper_post_order(self, node):
        if node:
            self.helper_post_order(node.left)
            self.helper_post_order(node.right)
            print(node.value,end = " ")

    def total_elements(self):
        def count(node):
            if node is None:
                return 0
            left = count(node.left)
            right = count(node.right)
            return 1+ left + right
        
        return count(self.root)